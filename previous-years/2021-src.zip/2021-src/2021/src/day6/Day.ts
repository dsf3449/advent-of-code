export default class Day {
  daysUntilReproduction: number;

  numberOfFish: number;

  constructor(daysUntilReproduction: number, numberOfFish: number) {
    this.daysUntilReproduction = daysUntilReproduction;
    this.numberOfFish = numberOfFish;
  }
}
