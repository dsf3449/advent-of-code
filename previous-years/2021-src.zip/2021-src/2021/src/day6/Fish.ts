export default class Fish {
  daysTilReproduction: number;

  constructor(inputDays: number) {
    this.daysTilReproduction = inputDays;
  }
}
