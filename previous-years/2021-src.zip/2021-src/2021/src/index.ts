import runDay from "./day15/day15";

console.log(runDay(2));
