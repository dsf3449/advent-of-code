import { getPuzzleInput } from "./utils.mjs";

getPuzzleInput(1)
  .then((input) => console.log(input))
  .catch((err) => console.error(err));
