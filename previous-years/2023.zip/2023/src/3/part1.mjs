import { getPuzzleInputRel, isImported } from "../utils.mjs";

function handle(input) {
  const regex = /\d+/g;
  const map = [];
  const sum = 0;

  input.forEach(row => {
    map.push(row.split(``));
  });

  input.forEach((row, rowIdx) => {
    const matches = [...row.matchAll(regex)];

    matches.forEach(match => {
      const lengthOfNum = match[0].length;

      let iterRow = rowIdx - 1;
      let iterColumn = match.index - 1;


      console.log();
    })
    console.log();
  })

  console.log(input);
}

if (!isImported(import.meta.url)) {
  getPuzzleInputRel(import.meta.url, true).then(handle);
}
